package b4a.TempSensor;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.TempSensor", "b4a.TempSensor.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.TempSensor", "b4a.TempSensor.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.TempSensor.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _tools = null;
public static anywheresoftware.b4a.objects.Timer _textdelay = null;
public static boolean _alarmstate = false;
public static boolean _page2 = false;
public static String _oven = "";
public static String _shysteres = "";
public static String _ssetpoint = "";
public static String _hourincrease = "";
public static boolean _startincrease = false;
public static boolean _startdecrease = false;
public static boolean _alarm = false;
public anywheresoftware.b4a.objects.collections.List _displaydata = null;
public anywheresoftware.b4a.objects.LabelWrapper _label2 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label3 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label7 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittext1 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittext2 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label6 = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebutton2 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittext11 = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebutton11 = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebutton15 = null;
public static int _seconds = 0;
public static int _minute = 0;
public static int _hour = 0;
public static double _hysteres = 0;
public static double _setpoint = 0;
public static int _inputindex = 0;
public static String _ssource = "";
public static String _oldvaluesource = "";
public anywheresoftware.b4a.objects.SpinnerWrapper _inputsel = null;
public anywheresoftware.b4a.objects.LabelWrapper _selectedinput = null;
public b4a.TempSensor.starter _starter = null;
public b4a.TempSensor.myservice _myservice = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _in = null;
String _sinc = "";
String _sdec = "";
 //BA.debugLineNum = 71;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 72;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 73;BA.debugLine="tools = LoadBitmapResize(File.DirAssets, \"tools.";
_tools = anywheresoftware.b4a.keywords.Common.LoadBitmapResize(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"tools.png",anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (24)),anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (24)),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 75;BA.debugLine="Dim In As Intent";
_in = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 76;BA.debugLine="In.Initialize(\"android.settings.ACTION_NOTIFICATI";
_in.Initialize("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS","");
 //BA.debugLineNum = 77;BA.debugLine="StartActivity(In)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(_in.getObject()));
 //BA.debugLineNum = 78;BA.debugLine="displayData.Initialize";
mostCurrent._displaydata.Initialize();
 //BA.debugLineNum = 79;BA.debugLine="TextDelay.Initialize(\"TextDelay\", 5000)";
_textdelay.Initialize(processBA,"TextDelay",(long) (5000));
 //BA.debugLineNum = 80;BA.debugLine="TextDelay.Enabled = False";
_textdelay.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 82;BA.debugLine="Activity.LoadLayout(\"twolayouts1\")";
mostCurrent._activity.LoadLayout("twolayouts1",mostCurrent.activityBA);
 //BA.debugLineNum = 83;BA.debugLine="InputSel.Add(\"Single\")";
mostCurrent._inputsel.Add("Single");
 //BA.debugLineNum = 84;BA.debugLine="InputSel.Add(\"Splitter\")";
mostCurrent._inputsel.Add("Splitter");
 //BA.debugLineNum = 85;BA.debugLine="InputSel.Add(\"4-20 mA\")";
mostCurrent._inputsel.Add("4-20 mA");
 //BA.debugLineNum = 86;BA.debugLine="If File.Exists(File.DirInternal, \"displaydata.txt";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 87;BA.debugLine="ToastMessageShow(\"File doesen't exist!\", True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("File doesen't exist!"),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 88;BA.debugLine="displayData.Add(\"0000\")' oven temp";
mostCurrent._displaydata.Add((Object)("0000"));
 //BA.debugLineNum = 89;BA.debugLine="displayData.Add(\"25\")' hysteres";
mostCurrent._displaydata.Add((Object)("25"));
 //BA.debugLineNum = 90;BA.debugLine="displayData.Add(\"060\") 'setpoint";
mostCurrent._displaydata.Add((Object)("060"));
 //BA.debugLineNum = 91;BA.debugLine="displayData.Add(\"20\") 'Temperaturökning per timm";
mostCurrent._displaydata.Add((Object)("20"));
 //BA.debugLineNum = 92;BA.debugLine="displayData.Add(\"False\") 'ToggleButton 11 start";
mostCurrent._displaydata.Add((Object)("False"));
 //BA.debugLineNum = 93;BA.debugLine="displayData.Add(\"False\") 'ToggleButton15 start m";
mostCurrent._displaydata.Add((Object)("False"));
 //BA.debugLineNum = 94;BA.debugLine="displayData.Add(\"Single\") 'InputSel val av ingån";
mostCurrent._displaydata.Add((Object)("Single"));
 //BA.debugLineNum = 97;BA.debugLine="File.WriteList(File.Dirinternal, \"displaydata.tx";
anywheresoftware.b4a.keywords.Common.File.WriteList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt",mostCurrent._displaydata);
 }else {
 //BA.debugLineNum = 100;BA.debugLine="displayData = File.ReadList(File.DirInternal, \"";
mostCurrent._displaydata = anywheresoftware.b4a.keywords.Common.File.ReadList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt");
 //BA.debugLineNum = 101;BA.debugLine="Label2.Text	= displayData.Get(0) 'oven temp";
mostCurrent._label2.setText(BA.ObjectToCharSequence(mostCurrent._displaydata.Get((int) (0))));
 //BA.debugLineNum = 102;BA.debugLine="oven = displayData.Get(0)";
mostCurrent._oven = BA.ObjectToString(mostCurrent._displaydata.Get((int) (0)));
 //BA.debugLineNum = 103;BA.debugLine="EditText1.Text = displayData.Get(1) 'hysteres";
mostCurrent._edittext1.setText(BA.ObjectToCharSequence(mostCurrent._displaydata.Get((int) (1))));
 //BA.debugLineNum = 104;BA.debugLine="shysteres = displayData.Get(1)";
mostCurrent._shysteres = BA.ObjectToString(mostCurrent._displaydata.Get((int) (1)));
 //BA.debugLineNum = 105;BA.debugLine="EditText2.Text = displayData.Get(2) 'setpoint";
mostCurrent._edittext2.setText(BA.ObjectToCharSequence(mostCurrent._displaydata.Get((int) (2))));
 //BA.debugLineNum = 106;BA.debugLine="ssetPoint = displayData.Get(2)";
mostCurrent._ssetpoint = BA.ObjectToString(mostCurrent._displaydata.Get((int) (2)));
 //BA.debugLineNum = 107;BA.debugLine="hourIncrease = displayData.Get(3) 'Temperaturök";
mostCurrent._hourincrease = BA.ObjectToString(mostCurrent._displaydata.Get((int) (3)));
 //BA.debugLineNum = 109;BA.debugLine="Dim SInc As String = displayData.Get(4) 'ToggleB";
_sinc = BA.ObjectToString(mostCurrent._displaydata.Get((int) (4)));
 //BA.debugLineNum = 110;BA.debugLine="If SInc = \"True\" Then";
if ((_sinc).equals("True")) { 
 //BA.debugLineNum = 111;BA.debugLine="startIncrease = True";
_startincrease = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 113;BA.debugLine="startIncrease = False";
_startincrease = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 115;BA.debugLine="Dim SDec As String = displayData.Get(5) 'ToggleB";
_sdec = BA.ObjectToString(mostCurrent._displaydata.Get((int) (5)));
 //BA.debugLineNum = 116;BA.debugLine="If SDec = \"True\" Then";
if ((_sdec).equals("True")) { 
 //BA.debugLineNum = 117;BA.debugLine="startDecrease = True";
_startdecrease = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 119;BA.debugLine="startDecrease = False";
_startdecrease = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 122;BA.debugLine="If startIncrease = True Or startDecrease = True";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True || _startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 123;BA.debugLine="Starter.autoCSPoint.Enabled = True";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.True);
 };
 //BA.debugLineNum = 125;BA.debugLine="sSource = displayData.Get(6)";
mostCurrent._ssource = BA.ObjectToString(mostCurrent._displaydata.Get((int) (6)));
 //BA.debugLineNum = 126;BA.debugLine="oLdValueSource = sSource";
mostCurrent._oldvaluesource = mostCurrent._ssource;
 //BA.debugLineNum = 127;BA.debugLine="If sSource = \"Single\" Then InputSel.SelectedInde";
if ((mostCurrent._ssource).equals("Single")) { 
mostCurrent._inputsel.setSelectedIndex((int) (0));};
 //BA.debugLineNum = 128;BA.debugLine="If sSource = \"Splitter\" Then InputSel.SelectedIn";
if ((mostCurrent._ssource).equals("Splitter")) { 
mostCurrent._inputsel.setSelectedIndex((int) (1));};
 //BA.debugLineNum = 129;BA.debugLine="If sSource = \"4-20 mA\" Then InputSel.SelectedInd";
if ((mostCurrent._ssource).equals("4-20 mA")) { 
mostCurrent._inputsel.setSelectedIndex((int) (2));};
 };
 //BA.debugLineNum = 131;BA.debugLine="If sSource = (\"Single\") Then SelectedInput.Text =";
if ((mostCurrent._ssource).equals(("Single"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Single"));};
 //BA.debugLineNum = 132;BA.debugLine="If sSource = (\"Splitter\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("Splitter"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Splitter"));};
 //BA.debugLineNum = 133;BA.debugLine="If sSource = (\"4-20 mA\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("4-20 mA"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("4-20 mA"));};
 //BA.debugLineNum = 134;BA.debugLine="Label6.Color = Colors.Green";
mostCurrent._label6.setColor(anywheresoftware.b4a.keywords.Common.Colors.Green);
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 254;BA.debugLine="StartServiceAt(Starter, DateTime.Now + 1 * DateTi";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(mostCurrent._starter.getObject()),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+1*anywheresoftware.b4a.keywords.Common.DateTime.TicksPerSecond),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 137;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return "";
}
public static void  _beepsound() throws Exception{
ResumableSub_BeepSound rsub = new ResumableSub_BeepSound(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_BeepSound extends BA.ResumableSub {
public ResumableSub_BeepSound(b4a.TempSensor.main parent) {
this.parent = parent;
}
b4a.TempSensor.main parent;
anywheresoftware.b4a.audio.Beeper _b = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 314;BA.debugLine="If ToggleButton2.Checked = True Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent.mostCurrent._togglebutton2.getChecked()==anywheresoftware.b4a.keywords.Common.True) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 315;BA.debugLine="Dim b As Beeper";
_b = new anywheresoftware.b4a.audio.Beeper();
 //BA.debugLineNum = 316;BA.debugLine="b.Initialize(500,1933)";
_b.Initialize((int) (500),(int) (1933));
 //BA.debugLineNum = 317;BA.debugLine="b.Beep";
_b.Beep();
 //BA.debugLineNum = 318;BA.debugLine="Sleep(500)";
anywheresoftware.b4a.keywords.Common.Sleep(mostCurrent.activityBA,this,(int) (500));
this.state = 5;
return;
case 5:
//C
this.state = 4;
;
 //BA.debugLineNum = 319;BA.debugLine="b.Release";
_b.Release();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 322;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 497;BA.debugLine="Sub Button1_Click 'Till tempökning sida 2";
 //BA.debugLineNum = 499;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 501;BA.debugLine="Activity.RemoveAllViews";
mostCurrent._activity.RemoveAllViews();
 //BA.debugLineNum = 502;BA.debugLine="Activity.LoadLayout(\"twolayouts2\")";
mostCurrent._activity.LoadLayout("twolayouts2",mostCurrent.activityBA);
 //BA.debugLineNum = 504;BA.debugLine="EditText11.Text = hourIncrease";
mostCurrent._edittext11.setText(BA.ObjectToCharSequence(mostCurrent._hourincrease));
 //BA.debugLineNum = 507;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 508;BA.debugLine="ToggleButton11.Checked = True";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 510;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 513;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 514;BA.debugLine="ToggleButton15.Checked = True";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 516;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 519;BA.debugLine="page2 = True";
_page2 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 522;BA.debugLine="If ToggleButton2.Checked = False Then";
if (mostCurrent._togglebutton2.getChecked()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 524;BA.debugLine="alarm = False";
_alarm = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 525;BA.debugLine="alarmState = False";
_alarmstate = anywheresoftware.b4a.keywords.Common.False;
 }else {
 //BA.debugLineNum = 527;BA.debugLine="alarm = True";
_alarm = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 528;BA.debugLine="alarmState = True";
_alarmstate = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 533;BA.debugLine="End Sub";
return "";
}
public static String  _button11_click() throws Exception{
String _sinc = "";
String _sdec = "";
 //BA.debugLineNum = 420;BA.debugLine="Sub Button11_Click 'Tillbaka till huvudsidan. sida";
 //BA.debugLineNum = 421;BA.debugLine="Activity.RemoveAllViews";
mostCurrent._activity.RemoveAllViews();
 //BA.debugLineNum = 422;BA.debugLine="Activity.LoadLayout(\"twolayouts1\")";
mostCurrent._activity.LoadLayout("twolayouts1",mostCurrent.activityBA);
 //BA.debugLineNum = 423;BA.debugLine="InputSel.Add(\"Single\")";
mostCurrent._inputsel.Add("Single");
 //BA.debugLineNum = 424;BA.debugLine="InputSel.Add(\"Splitter\")";
mostCurrent._inputsel.Add("Splitter");
 //BA.debugLineNum = 425;BA.debugLine="InputSel.Add(\"4-20 mA\")";
mostCurrent._inputsel.Add("4-20 mA");
 //BA.debugLineNum = 426;BA.debugLine="selectExistingItemInSpinner( InputSel, sSource, T";
_selectexistingiteminspinner(mostCurrent._inputsel,mostCurrent._ssource,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 427;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 428;BA.debugLine="If page2 Then";
if (_page2) { 
 //BA.debugLineNum = 429;BA.debugLine="displayData = File.ReadList(File.DirInternal, \"";
mostCurrent._displaydata = anywheresoftware.b4a.keywords.Common.File.ReadList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt");
 //BA.debugLineNum = 430;BA.debugLine="hourIncrease = EditText11.Text";
mostCurrent._hourincrease = mostCurrent._edittext11.getText();
 //BA.debugLineNum = 431;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 432;BA.debugLine="ToggleButton11.Checked = True";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 434;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 437;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 438;BA.debugLine="ToggleButton15.Checked = True";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 440;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 443;BA.debugLine="Label2.Text	= oven 'oven temp";
mostCurrent._label2.setText(BA.ObjectToCharSequence(mostCurrent._oven));
 //BA.debugLineNum = 444;BA.debugLine="EditText1.Text = shysteres 'hysteres";
mostCurrent._edittext1.setText(BA.ObjectToCharSequence(mostCurrent._shysteres));
 //BA.debugLineNum = 445;BA.debugLine="EditText2.Text = ssetPoint 'setpoint";
mostCurrent._edittext2.setText(BA.ObjectToCharSequence(mostCurrent._ssetpoint));
 //BA.debugLineNum = 447;BA.debugLine="displayData.Add(oven)' oven temp";
mostCurrent._displaydata.Add((Object)(mostCurrent._oven));
 //BA.debugLineNum = 448;BA.debugLine="displayData.Add(shysteres)' hysteres";
mostCurrent._displaydata.Add((Object)(mostCurrent._shysteres));
 //BA.debugLineNum = 449;BA.debugLine="displayData.Add(ssetPoint) 'setpoint";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssetpoint));
 //BA.debugLineNum = 450;BA.debugLine="displayData.Add(hourIncrease)' Ökning per timme";
mostCurrent._displaydata.Add((Object)(mostCurrent._hourincrease));
 //BA.debugLineNum = 451;BA.debugLine="Dim SInc As String";
_sinc = "";
 //BA.debugLineNum = 452;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 453;BA.debugLine="SInc = \"True\"";
_sinc = "True";
 }else {
 //BA.debugLineNum = 455;BA.debugLine="SInc = \"False\"";
_sinc = "False";
 };
 //BA.debugLineNum = 457;BA.debugLine="displayData.Add(SInc) 'ToggleButton11 start ökni";
mostCurrent._displaydata.Add((Object)(_sinc));
 //BA.debugLineNum = 458;BA.debugLine="Dim SDec As String";
_sdec = "";
 //BA.debugLineNum = 459;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 460;BA.debugLine="SDec = \"True\"";
_sdec = "True";
 }else {
 //BA.debugLineNum = 462;BA.debugLine="SDec = \"False\"";
_sdec = "False";
 };
 //BA.debugLineNum = 464;BA.debugLine="displayData.Add(SDec) 'ToggleButton15 start mins";
mostCurrent._displaydata.Add((Object)(_sdec));
 //BA.debugLineNum = 466;BA.debugLine="displayData.Add(sSource)";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssource));
 //BA.debugLineNum = 467;BA.debugLine="File.WriteList(File.Dirinternal, \"displaydata.tx";
anywheresoftware.b4a.keywords.Common.File.WriteList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt",mostCurrent._displaydata);
 //BA.debugLineNum = 468;BA.debugLine="If sSource = (\"Single\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("Single"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Single"));};
 //BA.debugLineNum = 469;BA.debugLine="If sSource = (\"Splitter\") Then SelectedInput.Tex";
if ((mostCurrent._ssource).equals(("Splitter"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Splitter"));};
 //BA.debugLineNum = 470;BA.debugLine="If sSource = (\"4-20 mA\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("4-20 mA"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("4-20 mA"));};
 };
 //BA.debugLineNum = 472;BA.debugLine="Label6.Color = Colors.Green";
mostCurrent._label6.setColor(anywheresoftware.b4a.keywords.Common.Colors.Green);
 //BA.debugLineNum = 473;BA.debugLine="If alarmState = False Then";
if (_alarmstate==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 474;BA.debugLine="ToggleButton2.Checked = False";
mostCurrent._togglebutton2.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 476;BA.debugLine="alarm = False";
_alarm = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 478;BA.debugLine="page2 = False";
_page2 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 480;BA.debugLine="End Sub";
return "";
}
public static String  _button12_click() throws Exception{
 //BA.debugLineNum = 580;BA.debugLine="Sub Button12_Click";
 //BA.debugLineNum = 582;BA.debugLine="End Sub";
return "";
}
public static String  _changelabel() throws Exception{
 //BA.debugLineNum = 324;BA.debugLine="Sub changeLabel";
 //BA.debugLineNum = 325;BA.debugLine="Label6.Color = Colors.Red";
mostCurrent._label6.setColor(anywheresoftware.b4a.keywords.Common.Colors.Red);
 //BA.debugLineNum = 326;BA.debugLine="End Sub";
return "";
}
public static String  _check_setpoint() throws Exception{
 //BA.debugLineNum = 617;BA.debugLine="Sub Check_Setpoint";
 //BA.debugLineNum = 619;BA.debugLine="seconds = DateTime.GetSecond(DateTime.Now)";
_seconds = anywheresoftware.b4a.keywords.Common.DateTime.GetSecond(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 620;BA.debugLine="minute = DateTime.GetMinute(DateTime.Now)";
_minute = anywheresoftware.b4a.keywords.Common.DateTime.GetMinute(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 621;BA.debugLine="hour = DateTime.GetHour(DateTime.Now)";
_hour = anywheresoftware.b4a.keywords.Common.DateTime.GetHour(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 622;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 623;BA.debugLine="If minute  = 0 Then";
if (_minute==0) { 
 //BA.debugLineNum = 624;BA.debugLine="ssetPoint = ssetPoint + hourIncrease ' Ökning";
mostCurrent._ssetpoint = BA.NumberToString((double)(Double.parseDouble(mostCurrent._ssetpoint))+(double)(Double.parseDouble(mostCurrent._hourincrease)));
 //BA.debugLineNum = 625;BA.debugLine="If ssetPoint > 1200 Then";
if ((double)(Double.parseDouble(mostCurrent._ssetpoint))>1200) { 
 //BA.debugLineNum = 626;BA.debugLine="ssetPoint = 1200";
mostCurrent._ssetpoint = BA.NumberToString(1200);
 //BA.debugLineNum = 627;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 628;BA.debugLine="startIncrease = False";
_startincrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 629;BA.debugLine="Starter.autoCSPoint.Enabled = False";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 631;BA.debugLine="EditText2.Text = ssetPoint";
mostCurrent._edittext2.setText(BA.ObjectToCharSequence(mostCurrent._ssetpoint));
 };
 };
 //BA.debugLineNum = 635;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 636;BA.debugLine="If minute = 0 Then";
if (_minute==0) { 
 //BA.debugLineNum = 637;BA.debugLine="ssetPoint = ssetPoint - hourIncrease ' Minsknin";
mostCurrent._ssetpoint = BA.NumberToString((double)(Double.parseDouble(mostCurrent._ssetpoint))-(double)(Double.parseDouble(mostCurrent._hourincrease)));
 //BA.debugLineNum = 638;BA.debugLine="If ssetPoint < 20 Then";
if ((double)(Double.parseDouble(mostCurrent._ssetpoint))<20) { 
 //BA.debugLineNum = 639;BA.debugLine="ssetPoint = 20";
mostCurrent._ssetpoint = BA.NumberToString(20);
 //BA.debugLineNum = 640;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 641;BA.debugLine="startDecrease = False";
_startdecrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 642;BA.debugLine="Starter.autoCSPoint.Enabled = False";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 645;BA.debugLine="EditText2.Text = ssetPoint";
mostCurrent._edittext2.setText(BA.ObjectToCharSequence(mostCurrent._ssetpoint));
 };
 };
 //BA.debugLineNum = 648;BA.debugLine="End Sub";
return "";
}
public static String  _edittext1_textchanged(String _old,String _new) throws Exception{
String _sinc = "";
String _sdec = "";
 //BA.debugLineNum = 257;BA.debugLine="Sub EditText1_TextChanged (Old As String, New As S";
 //BA.debugLineNum = 258;BA.debugLine="TextDelay.Enabled = True";
_textdelay.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 259;BA.debugLine="displayData.Clear";
mostCurrent._displaydata.Clear();
 //BA.debugLineNum = 260;BA.debugLine="displayData.Add(Label2.Text)' oven temp";
mostCurrent._displaydata.Add((Object)(mostCurrent._label2.getText()));
 //BA.debugLineNum = 261;BA.debugLine="displayData.Add(EditText1.Text)' hysteres";
mostCurrent._displaydata.Add((Object)(mostCurrent._edittext1.getText()));
 //BA.debugLineNum = 262;BA.debugLine="displayData.Add(EditText2.Text) 'setpoint";
mostCurrent._displaydata.Add((Object)(mostCurrent._edittext2.getText()));
 //BA.debugLineNum = 263;BA.debugLine="displayData.Add(hourIncrease) 'Temperaturökning";
mostCurrent._displaydata.Add((Object)(mostCurrent._hourincrease));
 //BA.debugLineNum = 264;BA.debugLine="Dim SInc As String";
_sinc = "";
 //BA.debugLineNum = 265;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 266;BA.debugLine="SInc = \"True\"";
_sinc = "True";
 }else {
 //BA.debugLineNum = 268;BA.debugLine="SInc = \"False\"";
_sinc = "False";
 };
 //BA.debugLineNum = 270;BA.debugLine="displayData.Add(SInc) 'ToggleButton11 start ökni";
mostCurrent._displaydata.Add((Object)(_sinc));
 //BA.debugLineNum = 271;BA.debugLine="Dim SDec As String";
_sdec = "";
 //BA.debugLineNum = 272;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 273;BA.debugLine="SDec = \"True\"";
_sdec = "True";
 }else {
 //BA.debugLineNum = 275;BA.debugLine="SDec = \"False\"";
_sdec = "False";
 };
 //BA.debugLineNum = 277;BA.debugLine="displayData.Add(SDec) 'ToggleButton15 start mins";
mostCurrent._displaydata.Add((Object)(_sdec));
 //BA.debugLineNum = 278;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 279;BA.debugLine="displayData.Add(sSource)";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssource));
 //BA.debugLineNum = 280;BA.debugLine="File.WriteList(File.Dirinternal, \"displaydata.tx";
anywheresoftware.b4a.keywords.Common.File.WriteList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt",mostCurrent._displaydata);
 //BA.debugLineNum = 281;BA.debugLine="If sSource = (\"Single\") Then SelectedInput.Text =";
if ((mostCurrent._ssource).equals(("Single"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Single"));};
 //BA.debugLineNum = 282;BA.debugLine="If sSource = (\"Splitter\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("Splitter"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Splitter"));};
 //BA.debugLineNum = 283;BA.debugLine="If sSource = (\"4-20 mA\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("4-20 mA"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("4-20 mA"));};
 //BA.debugLineNum = 284;BA.debugLine="End Sub";
return "";
}
public static String  _edittext11_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 536;BA.debugLine="Sub EditText11_TextChanged (Old As String, New As";
 //BA.debugLineNum = 537;BA.debugLine="If page2 = False Then";
if (_page2==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 538;BA.debugLine="displayData.Clear";
mostCurrent._displaydata.Clear();
 //BA.debugLineNum = 539;BA.debugLine="displayData.Add(oven)' oven temp";
mostCurrent._displaydata.Add((Object)(mostCurrent._oven));
 //BA.debugLineNum = 540;BA.debugLine="displayData.Add(shysteres)' hysteres";
mostCurrent._displaydata.Add((Object)(mostCurrent._shysteres));
 //BA.debugLineNum = 541;BA.debugLine="displayData.Add(ssetPoint) 'setpoint";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssetpoint));
 //BA.debugLineNum = 542;BA.debugLine="hourIncrease = New";
mostCurrent._hourincrease = _new;
 //BA.debugLineNum = 543;BA.debugLine="displayData.Add(hourIncrease) 'Temperaturökning";
mostCurrent._displaydata.Add((Object)(mostCurrent._hourincrease));
 //BA.debugLineNum = 544;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 545;BA.debugLine="ToggleButton11.Checked = True";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 547;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 549;BA.debugLine="displayData.Add(startIncrease) 'ToggleButton15 s";
mostCurrent._displaydata.Add((Object)(_startincrease));
 //BA.debugLineNum = 551;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 552;BA.debugLine="ToggleButton15.Checked = True";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 554;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 556;BA.debugLine="displayData.Add(startDecrease) 'ToggleButton15 s";
mostCurrent._displaydata.Add((Object)(_startdecrease));
 //BA.debugLineNum = 557;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 558;BA.debugLine="displayData.Add(sSource)";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssource));
 //BA.debugLineNum = 559;BA.debugLine="File.WriteList(File.Dirinternal, \"displaydata.tx";
anywheresoftware.b4a.keywords.Common.File.WriteList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt",mostCurrent._displaydata);
 //BA.debugLineNum = 560;BA.debugLine="If sSource = (\"Single\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("Single"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Single"));};
 //BA.debugLineNum = 561;BA.debugLine="If sSource = (\"Splitter\") Then SelectedInput.Tex";
if ((mostCurrent._ssource).equals(("Splitter"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Splitter"));};
 //BA.debugLineNum = 562;BA.debugLine="If sSource = (\"4-20 mA\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("4-20 mA"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("4-20 mA"));};
 }else {
 //BA.debugLineNum = 564;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 565;BA.debugLine="ToggleButton11.Checked = True";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 567;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 570;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 571;BA.debugLine="ToggleButton15.Checked = True";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 573;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 };
 };
 //BA.debugLineNum = 578;BA.debugLine="End Sub";
return "";
}
public static String  _edittext2_textchanged(String _old,String _new) throws Exception{
String _sinc = "";
String _sdec = "";
 //BA.debugLineNum = 328;BA.debugLine="Sub EditText2_TextChanged (Old As String, New As S";
 //BA.debugLineNum = 329;BA.debugLine="TextDelay.Enabled = True";
_textdelay.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 335;BA.debugLine="displayData.Clear";
mostCurrent._displaydata.Clear();
 //BA.debugLineNum = 336;BA.debugLine="displayData.Add(Label2.Text)' oven temp";
mostCurrent._displaydata.Add((Object)(mostCurrent._label2.getText()));
 //BA.debugLineNum = 337;BA.debugLine="displayData.Add(EditText1.Text)' hysteres";
mostCurrent._displaydata.Add((Object)(mostCurrent._edittext1.getText()));
 //BA.debugLineNum = 338;BA.debugLine="displayData.Add(EditText2.Text) 'setpoint";
mostCurrent._displaydata.Add((Object)(mostCurrent._edittext2.getText()));
 //BA.debugLineNum = 339;BA.debugLine="displayData.Add(hourIncrease) 'Temperaturökning p";
mostCurrent._displaydata.Add((Object)(mostCurrent._hourincrease));
 //BA.debugLineNum = 340;BA.debugLine="Dim SInc As String";
_sinc = "";
 //BA.debugLineNum = 341;BA.debugLine="If startIncrease = True Then";
if (_startincrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 342;BA.debugLine="SInc = \"True\"";
_sinc = "True";
 }else {
 //BA.debugLineNum = 344;BA.debugLine="SInc = \"False\"";
_sinc = "False";
 };
 //BA.debugLineNum = 346;BA.debugLine="displayData.Add(SInc) 'ToggleButton11 start öknin";
mostCurrent._displaydata.Add((Object)(_sinc));
 //BA.debugLineNum = 347;BA.debugLine="Dim SDec As String";
_sdec = "";
 //BA.debugLineNum = 348;BA.debugLine="If startDecrease = True Then";
if (_startdecrease==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 349;BA.debugLine="SDec = \"True\"";
_sdec = "True";
 }else {
 //BA.debugLineNum = 351;BA.debugLine="SDec = \"False\"";
_sdec = "False";
 };
 //BA.debugLineNum = 353;BA.debugLine="displayData.Add(SDec) 'ToggleButton15 start minsk";
mostCurrent._displaydata.Add((Object)(_sdec));
 //BA.debugLineNum = 354;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 355;BA.debugLine="displayData.Add(sSource)";
mostCurrent._displaydata.Add((Object)(mostCurrent._ssource));
 //BA.debugLineNum = 356;BA.debugLine="File.WriteList(File.Dirinternal, \"displaydata.txt";
anywheresoftware.b4a.keywords.Common.File.WriteList(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"displaydata.txt",mostCurrent._displaydata);
 //BA.debugLineNum = 357;BA.debugLine="If sSource = (\"Single\") Then SelectedInput.Text =";
if ((mostCurrent._ssource).equals(("Single"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Single"));};
 //BA.debugLineNum = 358;BA.debugLine="If sSource = (\"Splitter\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("Splitter"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("Splitter"));};
 //BA.debugLineNum = 359;BA.debugLine="If sSource = (\"4-20 mA\") Then SelectedInput.Text";
if ((mostCurrent._ssource).equals(("4-20 mA"))) { 
mostCurrent._selectedinput.setText(BA.ObjectToCharSequence("4-20 mA"));};
 //BA.debugLineNum = 361;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 29;BA.debugLine="Public alarmState As Boolean";
_alarmstate = false;
 //BA.debugLineNum = 30;BA.debugLine="Public page2 As Boolean = False";
_page2 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 31;BA.debugLine="Public oven As String = \"\"";
mostCurrent._oven = "";
 //BA.debugLineNum = 32;BA.debugLine="Public shysteres As String = \"\"";
mostCurrent._shysteres = "";
 //BA.debugLineNum = 33;BA.debugLine="Public ssetPoint As String = \"\"";
mostCurrent._ssetpoint = "";
 //BA.debugLineNum = 34;BA.debugLine="Public hourIncrease As String = \"\"";
mostCurrent._hourincrease = "";
 //BA.debugLineNum = 35;BA.debugLine="Public startIncrease As Boolean = False";
_startincrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 36;BA.debugLine="Public startDecrease As Boolean = False";
_startdecrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 38;BA.debugLine="Public alarm As Boolean = True";
_alarm = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 40;BA.debugLine="Public displayData As List";
mostCurrent._displaydata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 41;BA.debugLine="Public Label2 As Label  'Ugntemp";
mostCurrent._label2 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Public Label3 As Label";
mostCurrent._label3 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private Label7 As Label  'Larm";
mostCurrent._label7 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private EditText1 As EditText 'Hysteres";
mostCurrent._edittext1 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private EditText2 As EditText";
mostCurrent._edittext2 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private Label6 As Label";
mostCurrent._label6 = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private ToggleButton2 As ToggleButton";
mostCurrent._togglebutton2 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Private EditText11 As EditText 'Ökning per timme";
mostCurrent._edittext11 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 52;BA.debugLine="Private ToggleButton11 As ToggleButton";
mostCurrent._togglebutton11 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 53;BA.debugLine="Private ToggleButton15 As ToggleButton 'Aktivera";
mostCurrent._togglebutton15 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 54;BA.debugLine="DateTime.SetTimeZone(2)";
anywheresoftware.b4a.keywords.Common.DateTime.SetTimeZone(2);
 //BA.debugLineNum = 56;BA.debugLine="DateTime.TimeFormat=\"HH:mm:ss\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("HH:mm:ss");
 //BA.debugLineNum = 59;BA.debugLine="Public seconds As Int";
_seconds = 0;
 //BA.debugLineNum = 60;BA.debugLine="Public minute As Int";
_minute = 0;
 //BA.debugLineNum = 61;BA.debugLine="Public hour As Int";
_hour = 0;
 //BA.debugLineNum = 62;BA.debugLine="Public hysteres As Double";
_hysteres = 0;
 //BA.debugLineNum = 63;BA.debugLine="Public setPoint As Double";
_setpoint = 0;
 //BA.debugLineNum = 64;BA.debugLine="Public inputIndex As Int";
_inputindex = 0;
 //BA.debugLineNum = 65;BA.debugLine="Public sSource As String";
mostCurrent._ssource = "";
 //BA.debugLineNum = 66;BA.debugLine="Public oLdValueSource As String";
mostCurrent._oldvaluesource = "";
 //BA.debugLineNum = 67;BA.debugLine="Private InputSel As Spinner";
mostCurrent._inputsel = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 68;BA.debugLine="Private SelectedInput As Label";
mostCurrent._selectedinput = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public static String  _inputsel_selecteditemchanged() throws Exception{
 //BA.debugLineNum = 363;BA.debugLine="Sub InputSel_SelectedItemChanged";
 //BA.debugLineNum = 365;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
starter._process_globals();
myservice._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 21;BA.debugLine="Private tools As Bitmap";
_tools = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private TextDelay As Timer";
_textdelay = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public static String  _selectexistingiteminspinner(anywheresoftware.b4a.objects.SpinnerWrapper _inputselectval,String _ssourcenew,boolean _addtospinneritemsifnotpresent) throws Exception{
int _k = 0;
 //BA.debugLineNum = 482;BA.debugLine="Public Sub selectExistingItemInSpinner( InputSelec";
 //BA.debugLineNum = 483;BA.debugLine="For k=0 To InputSelectVal.size-1";
{
final int step1 = 1;
final int limit1 = (int) (_inputselectval.getSize()-1);
_k = (int) (0) ;
for (;_k <= limit1 ;_k = _k + step1 ) {
 //BA.debugLineNum = 484;BA.debugLine="If InputSelectVal.GetItem(k) = sSourceNew Then";
if ((_inputselectval.GetItem(_k)).equals(_ssourcenew)) { 
 //BA.debugLineNum = 485;BA.debugLine="InputSelectVal.SelectedIndex = k";
_inputselectval.setSelectedIndex(_k);
 //BA.debugLineNum = 486;BA.debugLine="InputSel.SelectedIndex = k";
mostCurrent._inputsel.setSelectedIndex(_k);
 //BA.debugLineNum = 487;BA.debugLine="Return";
if (true) return "";
 };
 }
};
 //BA.debugLineNum = 495;BA.debugLine="End Sub";
return "";
}
public static String  _setlabeltext(byte[] _pdata) throws Exception{
double[] _tempvalue = null;
double _scale = 0;
b4a.TempSensor.nb6 _n = null;
int _i = 0;
String _stemp = "";
double _ugntemp = 0;
double _mqttvalue = 0;
 //BA.debugLineNum = 143;BA.debugLine="Sub setLabelText(PData() As Byte)";
 //BA.debugLineNum = 144;BA.debugLine="Dim tempValue (PData.Length) As Double";
_tempvalue = new double[_pdata.length];
;
 //BA.debugLineNum = 145;BA.debugLine="Dim hysteres As Double";
_hysteres = 0;
 //BA.debugLineNum = 146;BA.debugLine="Dim setPoint As Double";
_setpoint = 0;
 //BA.debugLineNum = 147;BA.debugLine="Dim Scale As Double";
_scale = 0;
 //BA.debugLineNum = 148;BA.debugLine="Dim n As NB6";
_n = new b4a.TempSensor.nb6();
 //BA.debugLineNum = 149;BA.debugLine="For i = 0 To PData.Length-1";
{
final int step6 = 1;
final int limit6 = (int) (_pdata.length-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 150;BA.debugLine="tempValue(i) = PData(i)";
_tempvalue[_i] = _pdata[_i];
 }
};
 //BA.debugLineNum = 152;BA.debugLine="Dim sTemp As String = BytesToString(PData, 0, PD";
_stemp = anywheresoftware.b4a.keywords.Common.BytesToString(_pdata,(int) (0),_pdata.length,"UTF-8");
 //BA.debugLineNum = 156;BA.debugLine="sSource = InputSel.SelectedItem";
mostCurrent._ssource = mostCurrent._inputsel.getSelectedItem();
 //BA.debugLineNum = 157;BA.debugLine="If oLdValueSource <> sSource Then";
if ((mostCurrent._oldvaluesource).equals(mostCurrent._ssource) == false) { 
 //BA.debugLineNum = 158;BA.debugLine="selectExistingItemInSpinner( InputSel, sSource,";
_selectexistingiteminspinner(mostCurrent._inputsel,mostCurrent._ssource,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 159;BA.debugLine="EditText1_TextChanged (oLdValueSource, sSource)";
_edittext1_textchanged(mostCurrent._oldvaluesource,mostCurrent._ssource);
 //BA.debugLineNum = 160;BA.debugLine="oLdValueSource = sSource";
mostCurrent._oldvaluesource = mostCurrent._ssource;
 };
 //BA.debugLineNum = 164;BA.debugLine="If sSource = \"Single\" Then Scale = 0.29304029 'Sc";
if ((mostCurrent._ssource).equals("Single")) { 
_scale = 0.29304029;};
 //BA.debugLineNum = 165;BA.debugLine="If sSource = \"Splitter\" Then Scale = 0.29304029 '";
if ((mostCurrent._ssource).equals("Splitter")) { 
_scale = 0.29304029;};
 //BA.debugLineNum = 168;BA.debugLine="Dim ugnTemp As Double = sTemp";
_ugntemp = (double)(Double.parseDouble(_stemp));
 //BA.debugLineNum = 172;BA.debugLine="Dim mqttValue As Double = ugnTemp";
_mqttvalue = _ugntemp;
 //BA.debugLineNum = 173;BA.debugLine="ugnTemp = mqttValue * Scale";
_ugntemp = _mqttvalue*_scale;
 //BA.debugLineNum = 174;BA.debugLine="If sSource = \"4-20 mA\" Then";
if ((mostCurrent._ssource).equals("4-20 mA")) { 
 //BA.debugLineNum = 175;BA.debugLine="ugnTemp = (mqttValue-70) * 0.2948402948 '0.29484";
_ugntemp = (_mqttvalue-70)*0.2948402948;
 };
 //BA.debugLineNum = 187;BA.debugLine="Label2.Text = NumberFormat(ugnTemp, 0, 1)";
mostCurrent._label2.setText(BA.ObjectToCharSequence(anywheresoftware.b4a.keywords.Common.NumberFormat(_ugntemp,(int) (0),(int) (1))));
 //BA.debugLineNum = 188;BA.debugLine="oven = NumberFormat(ugnTemp, 0, 1)";
mostCurrent._oven = anywheresoftware.b4a.keywords.Common.NumberFormat(_ugntemp,(int) (0),(int) (1));
 //BA.debugLineNum = 189;BA.debugLine="hysteres = EditText1.Text";
_hysteres = (double)(Double.parseDouble(mostCurrent._edittext1.getText()));
 //BA.debugLineNum = 190;BA.debugLine="setPoint = EditText2.Text";
_setpoint = (double)(Double.parseDouble(mostCurrent._edittext2.getText()));
 //BA.debugLineNum = 192;BA.debugLine="Label7.Text = \"**************************\"";
mostCurrent._label7.setText(BA.ObjectToCharSequence("**************************"));
 //BA.debugLineNum = 193;BA.debugLine="Label6.Color = Colors.Green";
mostCurrent._label6.setColor(anywheresoftware.b4a.keywords.Common.Colors.Green);
 //BA.debugLineNum = 213;BA.debugLine="If ugnTemp > setPoint + hysteres Then";
if (_ugntemp>_setpoint+_hysteres) { 
 //BA.debugLineNum = 214;BA.debugLine="Label7.Text  = \"Ugnstemperaturen är hög!!\"";
mostCurrent._label7.setText(BA.ObjectToCharSequence("Ugnstemperaturen är hög!!"));
 //BA.debugLineNum = 216;BA.debugLine="If alarm = True Then";
if (_alarm==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 217;BA.debugLine="n.Initialize(\"default\", Application.LabelName,";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"HIGH")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 219;BA.debugLine="n.Build(\"LARM !!!\", \"Temperaturen är HÖG!!!\", \"";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("LARM !!!"),(Object)("Temperaturen är HÖG!!!"),"Tag",main.getObject()).Notify((int) (8));
 }else {
 //BA.debugLineNum = 221;BA.debugLine="n.Initialize(\"default\", Application.LabelName,";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"LOW")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 223;BA.debugLine="n.Build(\"LARM !!!\", \"Temperaturen är HÖG!!!\", \"";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("LARM !!!"),(Object)("Temperaturen är HÖG!!!"),"Tag",main.getObject()).Notify((int) (8));
 };
 }else {
 //BA.debugLineNum = 226;BA.debugLine="If ugnTemp < setPoint - hysteres Then";
if (_ugntemp<_setpoint-_hysteres) { 
 //BA.debugLineNum = 227;BA.debugLine="Label7.Text = \"Ugnstemperaturen är låg !!\"";
mostCurrent._label7.setText(BA.ObjectToCharSequence("Ugnstemperaturen är låg !!"));
 //BA.debugLineNum = 229;BA.debugLine="If alarm = True	Then";
if (_alarm==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 230;BA.debugLine="n.Initialize(\"default\", Application.LabelName,";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"HIGH")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 232;BA.debugLine="n.Build(\"LARM !!!\", \"Temperaturen är LÅG!!!\",";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("LARM !!!"),(Object)("Temperaturen är LÅG!!!"),"Tag",main.getObject()).Notify((int) (9));
 }else {
 //BA.debugLineNum = 234;BA.debugLine="n.Initialize(\"default\", Application.LabelName,";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"LOW")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 236;BA.debugLine="n.Build(\"LARM !!!\", \"Temperaturen är LÅG!!!\",";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("LARM !!!"),(Object)("Temperaturen är LÅG!!!"),"Tag",main.getObject()).Notify((int) (9));
 };
 };
 };
 //BA.debugLineNum = 241;BA.debugLine="shysteres = EditText1.Text 'hysteres";
mostCurrent._shysteres = mostCurrent._edittext1.getText();
 //BA.debugLineNum = 242;BA.debugLine="ssetPoint = EditText2.Text 'Setpoint";
mostCurrent._ssetpoint = mostCurrent._edittext2.getText();
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
return "";
}
public static String  _setstate() throws Exception{
 //BA.debugLineNum = 245;BA.debugLine="Sub SetState";
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public static String  _subnodata(int _count) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _larmtext = null;
int _tid = 0;
b4a.TempSensor.nb6 _n = null;
 //BA.debugLineNum = 286;BA.debugLine="Sub subNoData(count As Int)";
 //BA.debugLineNum = 287;BA.debugLine="Log(\"Entering subNoData!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5589825","Entering subNoData!",0);
 //BA.debugLineNum = 288;BA.debugLine="Dim lArmText As StringBuilder";
_larmtext = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 289;BA.debugLine="lArmText.Initialize";
_larmtext.Initialize();
 //BA.debugLineNum = 290;BA.debugLine="lArmText.Append(\"INGA TEMPVÄRDEN!!! på över \")";
_larmtext.Append("INGA TEMPVÄRDEN!!! på över ");
 //BA.debugLineNum = 291;BA.debugLine="Dim tid As Int = 1";
_tid = (int) (1);
 //BA.debugLineNum = 292;BA.debugLine="If (count*15)/60 < 1  Then";
if ((_count*15)/(double)60<1) { 
 //BA.debugLineNum = 293;BA.debugLine="tid = 0";
_tid = (int) (0);
 }else {
 //BA.debugLineNum = 295;BA.debugLine="tid = (count*15)/60";
_tid = (int) ((_count*15)/(double)60);
 };
 //BA.debugLineNum = 297;BA.debugLine="lArmText.Append(tid)";
_larmtext.Append(BA.NumberToString(_tid));
 //BA.debugLineNum = 298;BA.debugLine="lArmText.Append(\" Minuter!\")";
_larmtext.Append(" Minuter!");
 //BA.debugLineNum = 300;BA.debugLine="Dim n As NB6";
_n = new b4a.TempSensor.nb6();
 //BA.debugLineNum = 301;BA.debugLine="Label7.Text = \"??????????????????????????\"";
mostCurrent._label7.setText(BA.ObjectToCharSequence("??????????????????????????"));
 //BA.debugLineNum = 302;BA.debugLine="If alarm = True Then";
if (_alarm==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 303;BA.debugLine="n.Initialize(\"default\", Application.LabelName, \"";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"HIGH")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 305;BA.debugLine="n.Build(\"INGEN  D A T A !!!\", lArmText, \"Tag\", M";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("INGEN  D A T A !!!"),(Object)(_larmtext.getObject()),"Tag",main.getObject()).Notify((int) (10));
 }else {
 //BA.debugLineNum = 307;BA.debugLine="n.Initialize(\"default\", Application.LabelName, \"";
_n._initialize /*b4a.TempSensor.nb6*/ (processBA,"default",(Object)(anywheresoftware.b4a.keywords.Common.Application.getLabelName()),"LOW")._smallicon /*b4a.TempSensor.nb6*/ (_tools);
 //BA.debugLineNum = 309;BA.debugLine="n.Build(\"INGEN  D A T A !!!\", lArmText, \"Tag\", M";
_n._build /*anywheresoftware.b4a.objects.NotificationWrapper*/ ((Object)("INGEN  D A T A !!!"),(Object)(_larmtext.getObject()),"Tag",main.getObject()).Notify((int) (10));
 };
 //BA.debugLineNum = 311;BA.debugLine="Log(\"Exit subNoData!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5589849","Exit subNoData!",0);
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
return "";
}
public static String  _textdelay_tick() throws Exception{
 //BA.debugLineNum = 369;BA.debugLine="Sub TextDelay_Tick";
 //BA.debugLineNum = 370;BA.debugLine="TextDelay.Enabled = False";
_textdelay.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 371;BA.debugLine="Log(\"Numbers initiated!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("5917506","Numbers initiated!",0);
 //BA.debugLineNum = 372;BA.debugLine="hysteres = EditText1.Text";
_hysteres = (double)(Double.parseDouble(mostCurrent._edittext1.getText()));
 //BA.debugLineNum = 373;BA.debugLine="setPoint = EditText2.Text";
_setpoint = (double)(Double.parseDouble(mostCurrent._edittext2.getText()));
 //BA.debugLineNum = 375;BA.debugLine="If hysteres < 0 Then hysteres = 0";
if (_hysteres<0) { 
_hysteres = 0;};
 //BA.debugLineNum = 376;BA.debugLine="If hysteres > 400 Then hysteres = 400";
if (_hysteres>400) { 
_hysteres = 400;};
 //BA.debugLineNum = 378;BA.debugLine="If setPoint < 0 Then setPoint = 0";
if (_setpoint<0) { 
_setpoint = 0;};
 //BA.debugLineNum = 379;BA.debugLine="If setPoint > 1200 Then setPoint = 1200";
if (_setpoint>1200) { 
_setpoint = 1200;};
 //BA.debugLineNum = 381;BA.debugLine="End Sub";
return "";
}
public static String  _togglebutton1_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Sub ToggleButton1_CheckedChange(Checked As Boolean";
 //BA.debugLineNum = 250;BA.debugLine="CallSub2(Starter, \"ToggleButtonChanged\", Checked)";
anywheresoftware.b4a.keywords.Common.CallSubNew2(processBA,(Object)(mostCurrent._starter.getObject()),"ToggleButtonChanged",(Object)(_checked));
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return "";
}
public static String  _togglebutton11_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 601;BA.debugLine="Sub ToggleButton11_CheckedChange(Checked As Boolea";
 //BA.debugLineNum = 603;BA.debugLine="If Checked Then";
if (_checked) { 
 //BA.debugLineNum = 604;BA.debugLine="ToggleButton11.Checked = True";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 605;BA.debugLine="startIncrease = True";
_startincrease = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 606;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 607;BA.debugLine="startDecrease = False";
_startdecrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 608;BA.debugLine="Starter.autoCSPoint.Enabled = True";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 610;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 611;BA.debugLine="startIncrease = False";
_startincrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 612;BA.debugLine="Starter.autoCSPoint.Enabled = False";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 615;BA.debugLine="End Sub";
return "";
}
public static String  _togglebutton15_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 584;BA.debugLine="Sub ToggleButton15_CheckedChange(Checked As Boolea";
 //BA.debugLineNum = 586;BA.debugLine="If Checked Then";
if (_checked) { 
 //BA.debugLineNum = 587;BA.debugLine="ToggleButton15.Checked = True";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 588;BA.debugLine="startDecrease = True";
_startdecrease = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 589;BA.debugLine="ToggleButton11.Checked = False";
mostCurrent._togglebutton11.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 590;BA.debugLine="startIncrease = False";
_startincrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 591;BA.debugLine="Starter.autoCSPoint.Enabled = True";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 593;BA.debugLine="ToggleButton15.Checked = False";
mostCurrent._togglebutton15.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 594;BA.debugLine="startDecrease = False";
_startdecrease = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 595;BA.debugLine="Starter.autoCSPoint.Enabled = False";
mostCurrent._starter._autocspoint /*anywheresoftware.b4a.objects.Timer*/ .setEnabled(anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 598;BA.debugLine="End Sub";
return "";
}
public static void  _togglebutton2_checkedchange(boolean _checked) throws Exception{
ResumableSub_ToggleButton2_CheckedChange rsub = new ResumableSub_ToggleButton2_CheckedChange(null,_checked);
rsub.resume(processBA, null);
}
public static class ResumableSub_ToggleButton2_CheckedChange extends BA.ResumableSub {
public ResumableSub_ToggleButton2_CheckedChange(b4a.TempSensor.main parent,boolean _checked) {
this.parent = parent;
this._checked = _checked;
}
b4a.TempSensor.main parent;
boolean _checked;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 384;BA.debugLine="If ToggleButton2.Checked = True Then";
if (true) break;

case 1:
//if
this.state = 16;
if (parent.mostCurrent._togglebutton2.getChecked()==anywheresoftware.b4a.keywords.Common.True) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 16;
 //BA.debugLineNum = 389;BA.debugLine="alarm = True";
parent._alarm = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 390;BA.debugLine="ToastMessageShow(\"Larm PÅ\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Larm PÅ"),anywheresoftware.b4a.keywords.Common.False);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 401;BA.debugLine="If page2 = False Then";
if (true) break;

case 6:
//if
this.state = 15;
if (parent._page2==anywheresoftware.b4a.keywords.Common.False) { 
this.state = 8;
}if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 402;BA.debugLine="Msgbox2Async(\"Vill du stänga av ljudet?\", \"ALAR";
anywheresoftware.b4a.keywords.Common.Msgbox2Async(BA.ObjectToCharSequence("Vill du stänga av ljudet?"),BA.ObjectToCharSequence("ALARM AV!"),"JA","Cancel","NEJ",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null)),processBA,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 403;BA.debugLine="Wait For Msgbox_Result (Result As Int)";
anywheresoftware.b4a.keywords.Common.WaitFor("msgbox_result", processBA, this, null);
this.state = 17;
return;
case 17:
//C
this.state = 9;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 404;BA.debugLine="If Result = DialogResponse.POSITIVE Then";
if (true) break;

case 9:
//if
this.state = 14;
if (_result==anywheresoftware.b4a.keywords.Common.DialogResponse.POSITIVE) { 
this.state = 11;
}else {
this.state = 13;
}if (true) break;

case 11:
//C
this.state = 14;
 //BA.debugLineNum = 405;BA.debugLine="ToggleButton2.Checked = False";
parent.mostCurrent._togglebutton2.setChecked(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 406;BA.debugLine="ToastMessageShow(\"Larm AV\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Larm AV"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 407;BA.debugLine="alarm = False";
parent._alarm = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 408;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 410;BA.debugLine="ToggleButton2.Enabled = False";
parent.mostCurrent._togglebutton2.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 411;BA.debugLine="ToggleButton2.Checked = True";
parent.mostCurrent._togglebutton2.setChecked(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 412;BA.debugLine="ToastMessageShow(\"Larm PÅ\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Larm PÅ"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 413;BA.debugLine="ToggleButton2.Enabled = True";
parent.mostCurrent._togglebutton2.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 414;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 14:
//C
this.state = 15;
;
 if (true) break;

case 15:
//C
this.state = 16;
;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 418;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _msgbox_result(int _result) throws Exception{
}
}
