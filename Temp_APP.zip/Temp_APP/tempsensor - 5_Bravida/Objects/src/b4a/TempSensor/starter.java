package b4a.TempSensor;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class starter extends  android.app.Service{
	public static class starter_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (starter) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, starter.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, true, BA.class);
		}

	}
    static starter mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return starter.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "b4a.TempSensor", "b4a.TempSensor.starter");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.TempSensor.starter", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!true && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (starter) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (true) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (starter) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (true)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (starter) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (true) {
            BA.LogInfo("** Service (starter) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (starter) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static boolean _working = false;
public static anywheresoftware.b4j.objects.MqttAsyncClientWrapper _client = null;
public static boolean _connected = false;
public static int _timecount = 0;
public static anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper _mo = null;
public static anywheresoftware.b4a.objects.NotificationListenerWrapper.NotificationListener _listener = null;
public static anywheresoftware.b4a.phone.Phone.PhoneWakeState _wakelock = null;
public static anywheresoftware.b4a.objects.Timer _tm = null;
public static anywheresoftware.b4a.objects.Timer _reconnect = null;
public static anywheresoftware.b4a.objects.Timer _beeptimer = null;
public static anywheresoftware.b4a.objects.Timer _autocspoint = null;
public static String _user = "";
public static String _password = "";
public b4a.TempSensor.main _main = null;
public b4a.TempSensor.myservice _myservice = null;
public static String  _acspoint_tick() throws Exception{
 //BA.debugLineNum = 199;BA.debugLine="Sub aCSPoint_tick";
 //BA.debugLineNum = 200;BA.debugLine="CallSub(Main, \"Check_Setpoint\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"Check_Setpoint");
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public static boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
 //BA.debugLineNum = 153;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return false;
}
public static String  _beeptm_tick() throws Exception{
 //BA.debugLineNum = 188;BA.debugLine="Sub beepTM_tick";
 //BA.debugLineNum = 189;BA.debugLine="CallSub(Main, \"BeepSound\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"BeepSound");
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
return "";
}
public static String  _client_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Sub client_Connected (Success As Boolean)";
 //BA.debugLineNum = 41;BA.debugLine="connected = Success";
_connected = _success;
 //BA.debugLineNum = 42;BA.debugLine="If Success Then";
if (_success) { 
 //BA.debugLineNum = 43;BA.debugLine="ToastMessageShow(\"Connected to broker!\", True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Connected to broker!"),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 44;BA.debugLine="Log(\"Connected to broker\")";
anywheresoftware.b4a.keywords.Common.LogImpl("01703940","Connected to broker",0);
 //BA.debugLineNum = 45;BA.debugLine="client.Subscribe(\"Termoelement\", 0)";
_client.Subscribe("Termoelement",(int) (0));
 //BA.debugLineNum = 46;BA.debugLine="Log(\"Subscribe to Termoelement.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("01703942","Subscribe to Termoelement.",0);
 }else {
 //BA.debugLineNum = 49;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("01703945",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)),0);
 };
 //BA.debugLineNum = 51;BA.debugLine="CallSub(Main, \"SetState\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"SetState");
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public static String  _client_disconnected() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub client_Disconnected";
 //BA.debugLineNum = 61;BA.debugLine="connected = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 63;BA.debugLine="CallSub(Main, \"SetState\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"SetState");
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public static String  _client_messagearrived(String _topic,byte[] _payload) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub client_MessageArrived (Topic As String, Payloa";
 //BA.debugLineNum = 67;BA.debugLine="Log(\"Message arrived. Topic=\")";
anywheresoftware.b4a.keywords.Common.LogImpl("01900545","Message arrived. Topic=",0);
 //BA.debugLineNum = 68;BA.debugLine="Log( Topic)";
anywheresoftware.b4a.keywords.Common.LogImpl("01900546",_topic,0);
 //BA.debugLineNum = 69;BA.debugLine="Log(\" payload: \")";
anywheresoftware.b4a.keywords.Common.LogImpl("01900547"," payload: ",0);
 //BA.debugLineNum = 70;BA.debugLine="Log(BytesToString(Payload, 0, Payload.Length, \"UT";
anywheresoftware.b4a.keywords.Common.LogImpl("01900548",anywheresoftware.b4a.keywords.Common.BytesToString(_payload,(int) (0),_payload.length,"UTF-8"),0);
 //BA.debugLineNum = 71;BA.debugLine="timeCount = 0";
_timecount = (int) (0);
 //BA.debugLineNum = 72;BA.debugLine="beepTimer.Enabled=False";
_beeptimer.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 76;BA.debugLine="CallSub2(Main, \"setLabelText\", Payload)";
anywheresoftware.b4a.keywords.Common.CallSubNew2(processBA,(Object)(mostCurrent._main.getObject()),"setLabelText",(Object)(_payload));
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public static void  _connectandreconnect() throws Exception{
ResumableSub_ConnectAndReconnect rsub = new ResumableSub_ConnectAndReconnect(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_ConnectAndReconnect extends BA.ResumableSub {
public ResumableSub_ConnectAndReconnect(b4a.TempSensor.starter parent) {
this.parent = parent;
}
b4a.TempSensor.starter parent;
String _clientid = "";
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 101;BA.debugLine="Do While working";
if (true) break;

case 1:
//do while
this.state = 20;
while (parent._working) {
this.state = 3;
if (true) break;
}
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 102;BA.debugLine="If client.IsInitialized Then client.Close";
if (true) break;

case 4:
//if
this.state = 9;
if (parent._client.IsInitialized()) { 
this.state = 6;
;}if (true) break;

case 6:
//C
this.state = 9;
parent._client.Close();
if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 103;BA.debugLine="Dim clientId As String = Rnd(0, 999999999) & Dat";
_clientid = BA.NumberToString(anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (999999999)))+BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 104;BA.debugLine="client.Initialize(\"client\", \"ssl://m24.cloudmqtt";
parent._client.Initialize(processBA,"client","ssl://m24.cloudmqtt.com:24471",_clientid);
 //BA.debugLineNum = 106;BA.debugLine="Dim mo As MqttConnectOptions";
parent._mo = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper();
 //BA.debugLineNum = 107;BA.debugLine="mo.Initialize(user, password)";
parent._mo.Initialize(parent._user,parent._password);
 //BA.debugLineNum = 108;BA.debugLine="Log(\"Trying to connect\")";
anywheresoftware.b4a.keywords.Common.LogImpl("02031624","Trying to connect",0);
 //BA.debugLineNum = 109;BA.debugLine="client.Connect2(mo)";
parent._client.Connect2((org.eclipse.paho.client.mqttv3.MqttConnectOptions)(parent._mo.getObject()));
 //BA.debugLineNum = 110;BA.debugLine="Wait For Mqtt_Connected (Success As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("mqtt_connected", processBA, this, null);
this.state = 21;
return;
case 21:
//C
this.state = 10;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 111;BA.debugLine="If Success Then";
if (true) break;

case 10:
//if
this.state = 19;
if (_success) { 
this.state = 12;
}else {
this.state = 18;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 112;BA.debugLine="Log(\"Mqtt connected\")";
anywheresoftware.b4a.keywords.Common.LogImpl("02031628","Mqtt connected",0);
 //BA.debugLineNum = 113;BA.debugLine="reconnect.Enabled = True";
parent._reconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 115;BA.debugLine="Do While working And client.Connected";
if (true) break;

case 13:
//do while
this.state = 16;
while (parent._working && parent._client.getConnected()) {
this.state = 15;
if (true) break;
}
if (true) break;

case 15:
//C
this.state = 13;
 //BA.debugLineNum = 116;BA.debugLine="client.Publish2(\"ping\", Array As Byte(0), 1, F";
parent._client.Publish2("ping",new byte[]{(byte) (0)},(int) (1),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 117;BA.debugLine="Sleep(5000)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (5000));
this.state = 22;
return;
case 22:
//C
this.state = 13;
;
 if (true) break;

case 16:
//C
this.state = 19;
;
 //BA.debugLineNum = 119;BA.debugLine="Log(\"Disconnected\")";
anywheresoftware.b4a.keywords.Common.LogImpl("02031635","Disconnected",0);
 if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 121;BA.debugLine="Log(\"Error connecting.\")";
anywheresoftware.b4a.keywords.Common.LogImpl("02031637","Error connecting.",0);
 if (true) break;

case 19:
//C
this.state = 1;
;
 //BA.debugLineNum = 123;BA.debugLine="Sleep(5000)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (5000));
this.state = 23;
return;
case 23:
//C
this.state = 1;
;
 if (true) break;

case 20:
//C
this.state = -1;
;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _mqtt_connected(boolean _success) throws Exception{
}
public static String  _listener_notificationposted(anywheresoftware.b4a.objects.NotificationListenerWrapper.StatusBarNotificationWrapper _sbn) throws Exception{
anywheresoftware.b4a.phone.Phone _p = null;
anywheresoftware.b4j.object.JavaObject _jno = null;
anywheresoftware.b4j.object.JavaObject _extras = null;
String _title = "";
 //BA.debugLineNum = 127;BA.debugLine="Sub Listener_NotificationPosted (SBN As StatusBarN";
 //BA.debugLineNum = 128;BA.debugLine="Log(\"NotificationPosted, package = \" & SBN.Packag";
anywheresoftware.b4a.keywords.Common.LogImpl("02097153","NotificationPosted, package = "+_sbn.getPackageName()+", id = "+BA.NumberToString(_sbn.getId())+", text = "+_sbn.getTickerText(),0);
 //BA.debugLineNum = 130;BA.debugLine="Dim p As Phone";
_p = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 131;BA.debugLine="If p.SdkVersion >= 19 Then";
if (_p.getSdkVersion()>=19) { 
 //BA.debugLineNum = 132;BA.debugLine="Dim jno As JavaObject = SBN.Notification";
_jno = new anywheresoftware.b4j.object.JavaObject();
_jno = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_sbn.getNotification().getObject()));
 //BA.debugLineNum = 133;BA.debugLine="Dim extras As JavaObject = jno.GetField(\"extras\"";
_extras = new anywheresoftware.b4j.object.JavaObject();
_extras = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jno.GetField("extras")));
 //BA.debugLineNum = 134;BA.debugLine="extras.RunMethod(\"size\", Null)";
_extras.RunMethod("size",(Object[])(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 135;BA.debugLine="Log(extras)";
anywheresoftware.b4a.keywords.Common.LogImpl("02097160",BA.ObjectToString(_extras),0);
 //BA.debugLineNum = 136;BA.debugLine="Dim title As String = extras.RunMethod(\"getStrin";
_title = BA.ObjectToString(_extras.RunMethod("getString",new Object[]{(Object)("android.title")}));
 //BA.debugLineNum = 137;BA.debugLine="LogColor(\"Title = \" & title, Colors.Blue)";
anywheresoftware.b4a.keywords.Common.LogImpl("02097162","Title = "+_title,anywheresoftware.b4a.keywords.Common.Colors.Blue);
 };
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return "";
}
public static String  _listener_notificationremoved(anywheresoftware.b4a.objects.NotificationListenerWrapper.StatusBarNotificationWrapper _sbn) throws Exception{
 //BA.debugLineNum = 141;BA.debugLine="Sub Listener_NotificationRemoved (SBN As StatusBar";
 //BA.debugLineNum = 142;BA.debugLine="Log(\"NotificationRemoved, package = \" & SBN.Packa";
anywheresoftware.b4a.keywords.Common.LogImpl("02162689","NotificationRemoved, package = "+_sbn.getPackageName()+", id = "+BA.NumberToString(_sbn.getId())+", text = "+_sbn.getTickerText(),0);
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private working As Boolean = True";
_working = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 9;BA.debugLine="Private client As MqttClient";
_client = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Public connected As Boolean";
_connected = false;
 //BA.debugLineNum = 11;BA.debugLine="Public timeCount As Int = 0";
_timecount = (int) (0);
 //BA.debugLineNum = 12;BA.debugLine="Dim mo As MqttConnectOptions";
_mo = new anywheresoftware.b4j.objects.MqttAsyncClientWrapper.MqttConnectOptionsWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private listener As NotificationListener";
_listener = new anywheresoftware.b4a.objects.NotificationListenerWrapper.NotificationListener();
 //BA.debugLineNum = 14;BA.debugLine="Dim wakelock As PhoneWakeState";
_wakelock = new anywheresoftware.b4a.phone.Phone.PhoneWakeState();
 //BA.debugLineNum = 16;BA.debugLine="Dim tm As Timer";
_tm = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 17;BA.debugLine="Dim reconnect As Timer";
_reconnect = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 18;BA.debugLine="Dim beepTimer As Timer";
_beeptimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 19;BA.debugLine="Dim autoCSPoint As Timer";
_autocspoint = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 20;BA.debugLine="Private user As String = \"maosquaa\"";
_user = "maosquaa";
 //BA.debugLineNum = 21;BA.debugLine="Private password As String = \"YbRFNxmP5VI3\"";
_password = "YbRFNxmP5VI3";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public static String  _reconnect_tick() throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Sub reconnect_tick";
 //BA.debugLineNum = 165;BA.debugLine="Log(\"reconnect_tick\")";
anywheresoftware.b4a.keywords.Common.LogImpl("02424833","reconnect_tick",0);
 //BA.debugLineNum = 166;BA.debugLine="timeCount = timeCount + 1";
_timecount = (int) (_timecount+1);
 //BA.debugLineNum = 167;BA.debugLine="Log(timeCount)";
anywheresoftware.b4a.keywords.Common.LogImpl("02424835",BA.NumberToString(_timecount),0);
 //BA.debugLineNum = 169;BA.debugLine="If timeCount > 3 Then";
if (_timecount>3) { 
 //BA.debugLineNum = 170;BA.debugLine="CallSub(Main, \"changeLabel\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"changeLabel");
 //BA.debugLineNum = 172;BA.debugLine="ConnectAndReconnect";
_connectandreconnect();
 };
 //BA.debugLineNum = 175;BA.debugLine="If timeCount > 19 Then";
if (_timecount>19) { 
 //BA.debugLineNum = 176;BA.debugLine="reconnect.Enabled=False";
_reconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 177;BA.debugLine="beepTimer.Enabled=True";
_beeptimer.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 178;BA.debugLine="CallSub2(Main, \"subNoData\", timeCount)";
anywheresoftware.b4a.keywords.Common.CallSubNew2(processBA,(Object)(mostCurrent._main.getObject()),"subNoData",(Object)(_timecount));
 }else {
 };
 //BA.debugLineNum = 184;BA.debugLine="reconnect.Enabled=True";
_reconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 186;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 28;BA.debugLine="autoCSPoint.Initialize(\"aCSPoint\", 60000) 'Timer";
_autocspoint.Initialize(processBA,"aCSPoint",(long) (60000));
 //BA.debugLineNum = 29;BA.debugLine="Service.AutomaticForegroundMode = Service.AUTOMAT";
mostCurrent._service.AutomaticForegroundMode = mostCurrent._service.AUTOMATIC_FOREGROUND_ALWAYS;
 //BA.debugLineNum = 30;BA.debugLine="listener.Initialize(\"listener\")";
_listener.Initialize(processBA,"listener");
 //BA.debugLineNum = 36;BA.debugLine="working = True";
_working = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 37;BA.debugLine="ConnectAndReconnect";
_connectandreconnect();
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 194;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return "";
}
public static void  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
ResumableSub_Service_Start rsub = new ResumableSub_Service_Start(null,_startingintent);
rsub.resume(processBA, null);
}
public static class ResumableSub_Service_Start extends BA.ResumableSub {
public ResumableSub_Service_Start(b4a.TempSensor.starter parent,anywheresoftware.b4a.objects.IntentWrapper _startingintent) {
this.parent = parent;
this._startingintent = _startingintent;
}
b4a.TempSensor.starter parent;
anywheresoftware.b4a.objects.IntentWrapper _startingintent;
String _m = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _mtext = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 82;BA.debugLine="wakelock.PartialLock";
parent._wakelock.PartialLock(processBA);
 //BA.debugLineNum = 83;BA.debugLine="listener.HandleIntent(StartingIntent)";
parent._listener.HandleIntent(_startingintent);
 //BA.debugLineNum = 85;BA.debugLine="tm.Initialize(\"tm\",60000)";
parent._tm.Initialize(processBA,"tm",(long) (60000));
 //BA.debugLineNum = 86;BA.debugLine="tm.Enabled = True";
parent._tm.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 87;BA.debugLine="reconnect.Initialize(\"reconnect\", 15000)";
parent._reconnect.Initialize(processBA,"reconnect",(long) (15000));
 //BA.debugLineNum = 88;BA.debugLine="reconnect.Enabled=True";
parent._reconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 89;BA.debugLine="beepTimer.Initialize(\"beepTM\", 2000)";
parent._beeptimer.Initialize(processBA,"beepTM",(long) (2000));
 //BA.debugLineNum = 90;BA.debugLine="Dim m As String = DateTime.Now + 30 * 1000";
_m = BA.NumberToString(anywheresoftware.b4a.keywords.Common.DateTime.getNow()+30*1000);
 //BA.debugLineNum = 91;BA.debugLine="Dim mText As StringBuilder";
_mtext = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 92;BA.debugLine="mText.Initialize";
_mtext.Initialize();
 //BA.debugLineNum = 93;BA.debugLine="mText.Append(\"StartServiceAt: \")";
_mtext.Append("StartServiceAt: ");
 //BA.debugLineNum = 94;BA.debugLine="mText.Append (m)";
_mtext.Append(_m);
 //BA.debugLineNum = 95;BA.debugLine="If listener.HandleIntent(StartingIntent) Then Ret";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._listener.HandleIntent(_startingintent)) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
if (true) return ;
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 96;BA.debugLine="Sleep(0) 'allow the MessageReceived event to be r";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 97;BA.debugLine="Service.StopAutomaticForeground";
parent.mostCurrent._service.StopAutomaticForeground();
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _service_taskremoved() throws Exception{
 //BA.debugLineNum = 147;BA.debugLine="Sub Service_TaskRemoved";
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public static String  _tm_tick() throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="Sub tm_tick";
 //BA.debugLineNum = 158;BA.debugLine="tm.Enabled = False";
_tm.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 162;BA.debugLine="StartActivity(Main)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._main.getObject()));
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return "";
}
public static String  _togglebuttonchanged(boolean _state) throws Exception{
byte _b = (byte)0;
 //BA.debugLineNum = 54;BA.debugLine="Public Sub ToggleButtonChanged(state As Boolean)";
 //BA.debugLineNum = 55;BA.debugLine="Dim b As Byte";
_b = (byte)0;
 //BA.debugLineNum = 56;BA.debugLine="If state Then b = 1 Else b = 0";
if (_state) { 
_b = (byte) (1);}
else {
_b = (byte) (0);};
 //BA.debugLineNum = 57;BA.debugLine="client.Publish(\"Termoelement\", Array As Byte(b))";
_client.Publish("Termoelement",new byte[]{_b});
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
}
